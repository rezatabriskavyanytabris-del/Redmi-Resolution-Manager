package com.redmi.resolutionmanager

import android.os.RemoteException
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Shizuku UserService. It runs with the identity granted by Shizuku
 * (normally shell/ADB UID 2000 on a non-rooted device).
 */
class ShellUserService : IRemoteShell.Stub() {
    @Throws(RemoteException::class)
    override fun run(command: String): String {
        return try {
            // Only commands generated internally by this app are sent here.
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = BufferedReader(InputStreamReader(process.inputStream)).use {
                it.readText()
            }
            val exitCode = process.waitFor()
            "exit=$exitCode\n$output"
        } catch (e: Exception) {
            "ERROR: ${e.javaClass.simpleName}: ${e.message}"
        }
    }
}
