package com.redmi.resolutionmanager

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private data class Preset(val title: String, val width: Int, val height: Int, val dpi: Int)

    private val presets = listOf(
        Preset("360p • خیلی سبک", 270, 600, 140),
        Preset("480p • سبک", 360, 800, 180),
        Preset("480p+ • متعادل", 432, 960, 200),
        Preset("480p • وضوح بیشتر", 480, 1067, 220),
        Preset("720p • وضوح اصلی نمایشگر", 720, 1600, 320)
    )

    private lateinit var status: TextView
    private lateinit var current: TextView
    private lateinit var shellStatus: TextView
    private var remote: IRemoteShell? = null
    private var bound = false

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                updateStatus("مجوز Shizuku تأیید شد.")
                bindShell()
            } else {
                updateStatus("مجوز Shizuku رد شد. از داخل برنامه Shizuku اجازه بده.")
            }
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { refreshAccess() }
    }
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            remote = null
            updateStatus("ارتباط Shizuku قطع شد؛ سرویس را دوباره فعال کن.")
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = IRemoteShell.Stub.asInterface(service)
            runOnUiThread {
                updateStatus("اتصال Shell برقرار است.")
                readCurrent()
            }
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
            runOnUiThread { updateStatus("ارتباط سرویس قطع شد.") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 17, 25)
        window.navigationBarColor = Color.rgb(13, 17, 25)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildUi()
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListener(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        refreshAccess()
    }

    private fun buildUi() {
        val bg = Color.rgb(13, 17, 25)
        val panel = Color.rgb(25, 33, 46)
        val accent = Color.rgb(0, 200, 160)

        val scroll = ScrollView(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(column)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "REDMI RESOLUTION MANAGER"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        column.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "مدیریت رزولوشن و تراکم نمایشگر"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(18))
        }
        column.addView(subtitle, matchWrap())

        current = infoText("وضعیت فعلی: در حال بررسی…", panel)
        column.addView(current, matchWrap())

        status = infoText("وضعیت دسترسی: بررسی…", panel)
        column.addView(status, matchWrap().apply { topMargin = dp(8) })

        shellStatus = infoText("روش دسترسی: Shizuku UserService", panel)
        column.addView(shellStatus, matchWrap().apply { topMargin = dp(8); bottomMargin = dp(16) })

        addButton(column, "بررسی / اتصال به Shizuku", accent) {
            requestShizuku()
        }

        val heading = TextView(this).apply {
            text = "انتخاب کیفیت تصویر"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(22), 0, dp(10))
        }
        column.addView(heading, matchWrap())

        presets.forEach { preset ->
            addButton(column, "${preset.title}\n${preset.width} × ${preset.height}  •  DPI ${preset.dpi}", panel) {
                applyPreset(preset)
            }
        }

        val dpiHeading = TextView(this).apply {
            text = "تنظیم دستی DPI"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        }
        column.addView(dpiHeading, matchWrap())

        val dpiInput = EditText(this).apply {
            hint = "مثلاً 220"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
        }
        column.addView(dpiInput, matchWrap().apply { bottomMargin = dp(8) })

        addButton(column, "اعمال DPI دستی", accent) {
            val value = dpiInput.text.toString().toIntOrNull()
            if (value == null || value !in 80..600) {
                toast("DPI باید عددی بین 80 تا 600 باشد.")
            } else {
                execute("wm density $value")
            }
        }

        addButton(column, "خواندن وضعیت فعلی", panel) { readCurrent() }
        addButton(column, "بازگردانی کامل تنظیمات کارخانه", Color.rgb(115, 48, 55)) {
            execute("wm size reset && wm density reset")
        }

        val note = TextView(this).apply {
            text = "نکته: برای استفاده از این برنامه، Shizuku باید فعال باشد و مجوز برنامه را تأیید کرده باشی. در گوشی بدون روت، پس از راه‌اندازی مجدد ممکن است لازم باشد Shizuku دوباره راه‌اندازی شود."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(18), 0, 0)
        }
        column.addView(note, matchWrap())
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                updateStatus("Shizuku فعال نیست. ابتدا آن را راه‌اندازی کن.")
                toast("ابتدا Shizuku را Start کن.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindShell()
            } else {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (e: Exception) {
            updateStatus("خطا: ${e.message}")
        }
    }

    private fun refreshAccess() {
        try {
            if (!Shizuku.pingBinder()) {
                updateStatus("Shizuku اجرا نیست.")
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                updateStatus("Shizuku فعال و مجوز تأیید شده است.")
                bindShell()
            } else {
                updateStatus("Shizuku فعال است؛ مجوز برنامه هنوز داده نشده.")
            }
        } catch (e: Exception) {
            updateStatus("وضعیت نامشخص: ${e.message}")
        }
    }

    private fun bindShell() {
        if (bound && remote != null) return
        try {
            val args = Shizuku.UserServiceArgs(
                ComponentName(this, ShellUserService::class.java)
            ).daemon(false).processNameSuffix("resolution").version(1)
            Shizuku.bindUserService(args, connection)
            bound = true
            updateStatus("در حال اتصال به سرویس Shell…")
        } catch (e: Exception) {
            updateStatus("اتصال ناموفق: ${e.message}")
        }
    }

    private fun applyPreset(preset: Preset) {
        execute("wm size ${preset.width}x${preset.height} && wm density ${preset.dpi}")
    }

    private fun execute(command: String) {
        val service = remote
        if (service == null) {
            toast("ابتدا Shizuku را متصل کن.")
            requestShizuku()
            return
        }
        Thread {
            try {
                val result = service.run(command)
                runOnUiThread {
                    updateStatus("نتیجه اجرا:\n$result")
                    readCurrent()
                }
            } catch (e: Exception) {
                runOnUiThread { updateStatus("خطای اجرا: ${e.message}") }
            }
        }.start()
    }

    private fun readCurrent() {
        val service = remote ?: return
        Thread {
            try {
                val result = service.run("wm size; wm density")
                runOnUiThread { current.text = "وضعیت فعلی:\n$result" }
            } catch (e: Exception) {
                runOnUiThread { current.text = "خواندن وضعیت ناموفق: ${e.message}" }
            }
        }.start()
    }

    private fun infoText(textValue: String, color: Int) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun addButton(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            setOnClickListener { action() }
        }
        parent.addView(button, matchWrap().apply { bottomMargin = dp(8) })
    }

    private fun updateStatus(message: String) {
        if (::status.isInitialized) status.text = "وضعیت دسترسی:\n$message"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        if (bound) {
            try {
                Shizuku.unbindUserService(
                    Shizuku.UserServiceArgs(ComponentName(this, ShellUserService::class.java))
                        .daemon(false).processNameSuffix("resolution").version(1),
                    connection,
                    true
                )
            } catch (_: Exception) {}
        }
    }

    companion object {
        private const val REQUEST_CODE = 1001
    }
}
