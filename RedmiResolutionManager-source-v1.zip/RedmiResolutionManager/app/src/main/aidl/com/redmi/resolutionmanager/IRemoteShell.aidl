package com.redmi.resolutionmanager;

interface IRemoteShell {
    String run(String command);
}
