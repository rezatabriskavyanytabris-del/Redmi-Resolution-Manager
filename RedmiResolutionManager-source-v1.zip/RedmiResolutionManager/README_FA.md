# Redmi Resolution Manager

پروژه اندروید برای تغییر رزولوشن و DPI با Shizuku UserService.

## قابلیت‌ها
- رابط کاربری فارسی و تیره
- پروفایل‌های 270x600، 360x800، 432x960، 480x1067 و 720x1600
- تنظیم دستی DPI
- خواندن وضعیت فعلی با `wm size` و `wm density`
- بازگردانی با `wm size reset` و `wm density reset`
- درخواست مجوز Shizuku از داخل برنامه
- استفاده از UserService به‌جای API قدیمی `newProcess`

## ساخت APK
این پروژه به Android Studio، JDK 17 و Android SDK Platform 35 نیاز دارد.
در Android Studio پوشه اصلی پروژه را باز کن و منتظر Gradle Sync بمان.
سپس از پنجره Gradle، `:app:assembleDebug` را اجرا کن یا از Build > Build APK(s) استفاده کن.

خروجی:
`app/build/outputs/apk/debug/app-debug.apk`

## محدودیت مهم
- این سورس در محیط فعلی کامپایل و روی گوشی واقعی آزمایش نشده است.
- Shizuku باید جداگانه نصب و راه‌اندازی شود.
- در گوشی غیرروت، Shizuku پس از راه‌اندازی مجدد ممکن است نیاز به شروع مجدد داشته باشد.
- مجوز `WRITE_SECURE_SETTINGS` به‌تنهایی برای اجرای `wm size` کافی نیست.
- مقادیر DPI پیشنهادی هستند؛ ممکن است بسته به رام و سلیقه نیاز به تنظیم داشته باشند.
